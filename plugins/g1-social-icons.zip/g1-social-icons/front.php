<?php

// Prevent direct script access
if ( !defined('ABSPATH') )
    die ( 'No direct script access allowed' );
?>
<?php

require_once( plugin_dir_path( __FILE__ ) . '/shortcodes/shortcodes.php' );