/* global jQuery */
/* global g1PageBuilder */

(function ($) {
    "use strict";

    g1PageBuilder.setDebugMode(false);

    $(document).ready(function () {
        $('#postdivrich').g1Builder();
    });
})(jQuery);